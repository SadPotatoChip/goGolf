# goGolf
2D golf game made in go using the ebiten game creation library.

what we are going for:
https://www.youtube.com/watch?v=ihP5IYbp3fU

the ebiten webiste:
https://hajimehoshi.github.io/ebiten/

Projekat za programske paradigme (I smer)
Jovana Pejkic 435/2016
Nikola Ninkovic 262/2015

controls:
	up/down arrow adjust power
	left right arrow adjust angle
	space hits the ball

