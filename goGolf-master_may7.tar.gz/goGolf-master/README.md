# goGolf
2D golf game made in go using the ebiten game creation library

what we are going for:
https://www.youtube.com/watch?v=ihP5IYbp3fU

the ebiten webiste:
https://hajimehoshi.github.io/ebiten/

Projekat za programske paradigme (I smer)
Jovana Pejkic 435/2016
Nikola Ninkovic 262/2015

:o: Controls:

| Button        | Action          |
| ---           | ---             |
| 1             | go back         |
| :arrow_up:    | adjust power    |
| :arrow_down:  | adjust power    |
| :arrow_right: | adjust angle    |
| :arrow_left:  | adjust angle    |
| space         | hit the ball    |
| esc           | exit            |


:o: Compile and run:

| make       | 
| ---        |
