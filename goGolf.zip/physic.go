package main

import (
	"fmt"
	"image/color"

	"github.com/hajimehoshi/ebiten"
)

var maxSpeed float64 = 40
var gravityStrenght float64 = 0.05
var airFrictionStrenght float64 = 0.002
var groundFrictionStrenght float64 = 0.05

type ball struct {
	x, y                            float64
	graphic                         *ebiten.Image
	opts                            *ebiten.DrawImageOptions
	verticalSpeed, horisonatalSpeed float64
	isGrounded                      bool
}

func makeBall(x, y float64) *ball {
	tmp := new(ball)
	tmp.graphic, _ = ebiten.NewImage(5, 5, ebiten.FilterNearest)
	tmp.graphic.Fill(color.White)
	tmp.opts = &ebiten.DrawImageOptions{}
	tmp.x = x
	tmp.y = y
	tmp.opts.GeoM.Translate(x, y)
	tmp.verticalSpeed, tmp.horisonatalSpeed = 0, 0
	tmp.isGrounded = true

	return tmp
}

func (b *ball) applyNaturalForces() {
	if b.isGrounded == false {
		if b.verticalSpeed > -maxSpeed {
			b.verticalSpeed -= gravityStrenght
		}
		if b.horisonatalSpeed > 0 {
			b.horisonatalSpeed -= airFrictionStrenght
		}
		if b.horisonatalSpeed < 0 {
			b.horisonatalSpeed += airFrictionStrenght
		}
	} else {
		b.verticalSpeed = 0
		if b.horisonatalSpeed > 0 {
			b.horisonatalSpeed -= groundFrictionStrenght
		}
		if b.horisonatalSpeed < 0 {
			b.horisonatalSpeed += groundFrictionStrenght
		}
	}

}

func (b *ball) hit(power float64) {
	b.isGrounded = false
	b.horisonatalSpeed += power
	b.verticalSpeed += power
}

func (b *ball) move() {
	if b.horisonatalSpeed < 0.1 && b.horisonatalSpeed > -0.1 {
		b.horisonatalSpeed = 0
	}
	//HACK
	if b.y > screenHeight-10 && b.isGrounded == false {
		b.y = screenHeight - 10
		b.opts.GeoM.Reset()
		b.opts.GeoM.Translate(b.x, b.y)
		b.verticalBounce()
	} else {
		b.opts.GeoM.Translate(0, -b.verticalSpeed)
	}
	b.opts.GeoM.Translate(b.horisonatalSpeed, 0)

	b.x += b.horisonatalSpeed
	b.y -= b.verticalSpeed
}

func (b *ball) verticalBounce() {
	fmt.Printf("%f\n", b.verticalSpeed)
	if b.verticalSpeed < 0.3 && b.verticalSpeed > -0.3 {
		fmt.Printf("stop")
		b.isGrounded = true
		b.verticalSpeed = 0
	} else {
		b.verticalSpeed = -b.verticalSpeed * 0.5
	}
}
