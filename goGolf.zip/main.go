package main

import (
	"fmt"

	"github.com/hajimehoshi/ebiten"
	"github.com/hajimehoshi/ebiten/ebitenutil"
)

const screenWidth float64 = 1200
const screenHeight float64 = 600

var levelisInstantiating = true
var player *ball
var p float64

func main() {
	var w, h int = int(screenWidth), int(screenHeight)
	fmt.Printf("input shot strenght (try 1 first):\n")
	fmt.Scanf("%f", &p)
	if err := ebiten.Run(update, w, h, 1, "puff puff"); err != nil {
		panic(err)
	}
}

func update(screen *ebiten.Image) error {
	if levelisInstantiating {
		player = makeBall(100, 500)
		player.hit(p)
		levelisInstantiating = false
	}
	player.applyNaturalForces()
	player.move()

	screen.DrawImage(player.graphic, player.opts)

	ebitenutil.DebugPrint(screen, fmt.Sprintf("FPS:%f \nx:%f y:%f\nv:%f h:%f", ebiten.CurrentFPS(), player.x, player.y, player.horisonatalSpeed, player.verticalSpeed))

	return nil
}
